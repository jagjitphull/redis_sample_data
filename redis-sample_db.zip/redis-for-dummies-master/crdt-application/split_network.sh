#!/bin/bash

docker network disconnect network2 rp1
docker network disconnect network1 rp2
