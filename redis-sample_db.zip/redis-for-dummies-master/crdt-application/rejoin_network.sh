#!/bin/bash

docker network connect network2 rp1
docker network connect network1 rp2